<?php
namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller; // ✅ This line is required
use Illuminate\Http\Request;
use App\Models\Store;
use App\Models\Warehouse;
use App\Models\Customer;
use App\Models\AcAccount;
class StoreController extends Controller
{

    public function index()
    {
        $store = Store::all();
        

                if ($store->isEmpty()) {

                    return response()->json([
                        'message' => 'Detail Not Found',
                         'data'=>[],                       
                        'status' => 0
                    ], 200);

                }else{
                     
                     return response()->json([
                        'message' => 'store List',
                        'data'=>$store,
                        'status' => 1
                    ], 200);
                    
                }
    }

    // Store a new store
    public function store(Request $request)
    {
       

        $store = Store::create($request->all());
        if($store){

            

  $account = AcAccount::create($request->all());



        }

        return response()->json([
            'status'=>1,
            'message' => 'Store created successfully',
            'data' => $store
        ], 200);
    }

    // Update an existing Store
    public function update(Request $request, $id)
    {
        $store= Store::findOrFail($id);

        $store->update($request->all());

        return response()->json([
            'status'=>1,
            'message' => 'Store Details updated successfully',
            'data' => $store
        ]);
    }

    // View a single Store
    public function show($id)
    {
        $store = Store::findOrFail($id);
        return response()->json($store);
    }
      public function destroy($id)
    {
        $store = Store::findOrFail($id);
        $store->delete();
        return response()->json(['message' => 'Store deleted']);
    }
}


