@include('layouts.header')
@include('layouts.header-nav')
@yield('content')
@include('layouts.footer')
