<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\Api\SettingsController;
use App\Http\Controllers\Api\PackageController;
use App\Http\Controllers\Api\StoreController;
use App\Http\Controllers\Api\Ac_AccountController;
use App\Http\Controllers\Api\CustomerController;
use App\Http\Controllers\Api\WarehouseController; 
use App\Http\Controllers\Api\SupplierController;


// Route::get('/user', function (Request $request) {
//     return $request->user();
// })->middleware('auth:api');

Route::get('/settings-view/{id}',[SettingsController::class,'settingshow']);
Route::put('/settings-update/{id}',[SettingsController::class,'settingsupdate']);
Route::post('/register',[UserController::class,'register']);
Route::post('/login',[UserController::class,'login']);

Route::middleware('auth:api')->group(function (){
            
        Route::get('/user/{id}',[UserController::class,'getUser']);
        Route::put('/user-update/{id}', [UserController::class, 'update']);  

 });

 //Packages CRUD
Route::get('/packages-view', [PackageController::class, 'index']);
Route::get('/packages-view/{id}', [PackageController::class, 'show']);
Route::post('/packages-create', [PackageController::class, 'store']);
Route::put('/packages-update/{id}', [PackageController::class, 'update']);

//Store CRUD
Route::get('/store-view', [StoreController::class, 'index']);
Route::get('/store-view/{id}', [StoreController::class, 'show']);
Route::post('/store-create', [StoreController::class, 'store']);
Route::put('/store-update/{id}', [StoreController::class, 'update']);
Route::delete('/store-delete/{id}', [StoreController::class, 'destroy']);

//AcAccount CRUD
Route::get('/acaccount-view', [Ac_AccountController::class, 'index']);
Route::get('/acaccount-view/{id}', [Ac_AccountController::class, 'show']);
Route::post('/acaccount-create', [Ac_AccountController::class, 'store']);
Route::put('/acaccount-update/{id}', [Ac_AccountController::class, 'update']);
Route::delete('/acaccount-delete/{id}', [Ac_AccountController::class, 'destroy']);

//Customer CRUD
Route::get('/customer-view', [CustomerController::class, 'index']);
Route::get('/customer-view/{id}', [CustomerController::class, 'show']);
Route::post('/customer-create', [CustomerController::class, 'store']);
Route::put('/customer-update/{id}', [CustomerController::class, 'update']);
Route::delete('/customer-delete/{id}', [CustomerController::class, 'destroy']);

//Warhouse CRUD
Route::get('/warehouse-view', [WarehouseController::class, 'index']);
Route::get('/warehouse-view/{id}', [WarehouseController::class, 'show']);
Route::post('/warehouse-create', [WarehouseController::class, 'store']);
Route::put('/warehouse-update/{id}', [WarehouseController::class, 'update']);
Route::delete('/warehouse-delete/{id}', [WarehouseController::class, 'destroy']);

//Supplier CRUD
Route::get('/supplier-view', [SupplierController::class, 'index']);
Route::get('/supplier-view/{id}', [SupplierController::class, 'show']);
Route::post('/supplier-create', [SupplierController::class, 'store']);
Route::put('/supplier-update/{id}', [SupplierController::class, 'update']);
Route::delete('/supplier-delete/{id}', [SupplierController::class, 'destroy']);